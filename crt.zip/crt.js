const container = document.getElementById('lottie-container');
const magnet = document.getElementById('magnet-container');

//CRT
const animation = lottie.loadAnimation({
  container: container, // The container
  renderer: 'svg',
  loop: false,        // No loop
  autoplay: false,    // No autoplay the animation
  path: '/crt.json', 
});

/*//MAG
const mag = lottie.loadAnimation({
  magnet: magnet, // The container
  renderer: 'svg',
  loop: false,        // No loop
  autoplay: false,    // No autoplay the animation
  path: '/magnet.json', 
});*/

//animation.onload(12, true);

//Update animation based on cursor position
container.addEventListener('mousemove', (event) => {
  const rect = container.getBoundingClientRect();
 // const x = event.clientX - rect.right; // X position relative to container
  const y = event.clientY - rect.top;  // Y position relative to container

  // Calculate percentage positions
  //const xPercent = x / rect.width;  // 0 to 1
  const yPercent = y / rect.height; // 0 to 1

  // Determine the frame based on the Y position
  const totalFrames = animation.totalFrames;
  const frame = Math.floor(yPercent * totalFrames);

  // Go to the corresponding frame
  animation.goToAndStop(frame, true);
});
// Reset animation on mouse out
container.addEventListener('mouseleave', () => {
  animation.goToAndStop(12, true);
});


//Movable Div
const movableDiv = document.getElementById('movableDiv');
let isDragging = false;
let offsetX, offsetY;

movableDiv.addEventListener('mousedown',
  (e) => {
    isDragging = true;
    offsetX = e.clientX - movableDiv.offsetLeft;
    offsetY = e.clientY - movableDiv.offsetTop;
    movableDiv.style.cursor = "grabbing";
  });

document.addEventListener("mousemove",
  (e) => {
    if (!isDragging) return;
    let x = e.clientX - offsetX;
    let y = e.clientY - offsetY;
    movableDiv.style.left = '${x}px';
    movableDiv.style.top = '${y}px';
  });

document.addEventListener('mouseup', () => {
  isDragging = false;
  movableDiv.style.cursor = 'grab';
});